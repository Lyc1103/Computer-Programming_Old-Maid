struct Card
{
    int rank;
    int suit;
};

void init_cards(struct Card cards[53]);
void draw_card(int idx);